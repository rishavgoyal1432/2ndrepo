//
//  main.m
//  CheckmarxM1
//
//  Created by Denis Krivitski on 2/09/12.
//  Copyright (c) 2012 DDK Mobile. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "DKAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([DKAppDelegate class]));
    }
}
