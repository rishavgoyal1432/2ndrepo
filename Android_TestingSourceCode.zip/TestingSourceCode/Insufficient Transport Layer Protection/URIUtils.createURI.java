
public class Test3 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		URI uri = URIUtils.createURI("http", "www.google.com", -1, "/search",   "q=client&btnG=Google+Search&aq=f&oq=", null);
			HttpGet httpget = new HttpGet(uri);
			System.out.println(httpget.getURI());
			// TODO Auto-generated method stub

	}

}
