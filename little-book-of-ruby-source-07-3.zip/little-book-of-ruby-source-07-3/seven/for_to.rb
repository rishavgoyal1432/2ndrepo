# Ruby Sample program from www.sapphiresteel.com / www.bitwisemag.com

for i in 1..10 do
	puts( i )
end

(1..10).each do |i|
	puts(i)
end