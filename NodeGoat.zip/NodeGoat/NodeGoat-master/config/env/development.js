var devConfig = {
    //db: "mongodb://localhost/nodegoat"
};

module.exports = devConfig;
