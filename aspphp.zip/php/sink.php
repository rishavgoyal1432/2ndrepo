<?
	function do_work($a, $b) {
		print "a is $a and b is $b\n";
		mysql_query("SELECT " . $a . " FROM " . $b);
	}

	function do_other_work($x) {
		extract($x);
	}
?>
