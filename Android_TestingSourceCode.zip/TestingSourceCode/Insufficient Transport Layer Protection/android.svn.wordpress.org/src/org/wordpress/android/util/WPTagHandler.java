package org.wordpress.android.util;

import org.xml.sax.XMLReader;

import android.text.Editable;
import android.text.Spannable;

/*public class WPTagHandler implements org.wordpress.android.util.WPHtml.TagHandler {

	@Override
    public void handleTag(boolean opening, String tag, Editable output,
            XMLReader xmlReader) {
		int test = 0;
		test++;
        //output.append(xmlReader.getContentHandler().toString());
    }
}*/