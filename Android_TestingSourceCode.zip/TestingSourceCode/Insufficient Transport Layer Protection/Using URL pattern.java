import java.net.URL;
// No vulnerability here
// Using new URL pattern

public class Test5 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		URL url = new URL("http://www.myaddr.net/the/stuff");
		HTTPConnection con = new HTTPConnection(url);

	}

}
