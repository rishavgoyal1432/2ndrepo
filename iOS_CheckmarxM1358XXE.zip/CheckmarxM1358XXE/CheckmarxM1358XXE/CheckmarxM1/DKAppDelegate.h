//
//  DKAppDelegate.h
//  CheckmarxM1
//
//  Created by Denis Krivitski on 2/09/12.
//  Copyright (c) 2012 DDK Mobile. All rights reserved.
//

#import <UIKit/UIKit.h>

@class DKViewController;

@interface DKAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) DKViewController *viewController;

@end
