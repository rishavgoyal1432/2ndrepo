import java.net.*;
// No vulnerability here
// using HTTPGet shown

public class Test2 {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		HttpClient httpclient = new DefaultHttpClient();
		HttpGet httpget = new HttpGet("http://localhost/");
		HttpResponse response = httpclient.execute(httpget);
		HttpEntity entity = response.getEntity();
		if (entity != null) {
		    InputStream instream = entity.getContent();
		    int l;
		    byte[] tmp = new byte[2048];
		    while ((l = instream.read(tmp)) != -1) {
		    }
		}

	}

}
