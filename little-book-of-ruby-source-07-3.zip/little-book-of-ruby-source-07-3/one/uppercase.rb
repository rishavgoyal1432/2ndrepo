# Ruby Sample program from www.sapphiresteel.com / www.bitwisemag.com

puts( "hello world".upcase )