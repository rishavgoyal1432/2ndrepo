var prodConfig = {};

module.exports = prodConfig;
