The Little Book Of Ruby
written by
Huw Collingbourne
Copyright � 2006 Dark Neon Ltd. 
All rights reserved. 

This sample code is provided for use with the free Little Book Of Ruby eBook available from: http://www.sapphiresteel.com

This source code is compatible with Ruby 1.8x. Users of Ruby In Steel (beta 0.7) may load all the source code projects in the form of a single Visual Studio solution. Just load the solution file: 

littlebook_of_ruby.sln

You may freely copy and distribute the Little Book Of Ruby eBook and the accompanying source code as long as you do not modify the text or remove the copyright notice from the eBook. You must not make any charge for the eBook or the accompanying source code. 

The Little Book of Ruby is produced in association with Rosedown Mill Ltd., makers of the Steel IDE for Visual Studio (www.sapphiresteel.com) and Bitwise Magazine � the online magazine for developers (www.bitwisemag.com). 