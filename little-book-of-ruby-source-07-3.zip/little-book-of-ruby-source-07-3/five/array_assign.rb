# Ruby Sample program from www.sapphiresteel.com / www.bitwisemag.com

arr = [] 

arr[0] = [0]
arr[1] = ["one"]
arr[3] = ["a", "b", "c"]

p( arr ) # inspect and print arr

arr2 = ['h','e','l','l','o',' ','w','o','r','l','d']

arr2[0] = 'H'
arr2[2,3] = 'L', 'L'
arr2[4..5] = 'O','-','W'
arr2[-4,4] = 'a','l','d','o'

p( arr2 ) # inspect and print arr2
