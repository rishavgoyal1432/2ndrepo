# Ruby Sample program from www.sapphiresteel.com / www.bitwisemag.com

p( Dir.entries( 'C:\\' ) )