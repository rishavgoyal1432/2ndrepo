# Ruby Sample program from www.sapphiresteel.com / www.bitwisemag.com

def showstring
	puts( "Hello" )
end

def showname( aName )
	puts( "Hello #{aName}" )
end

def return_name( aFirstName, aSecondName )
	return "Hello #{aFirstName} #{aSecondName}"
end

def return_name2 aFirstName, aSecondName 
	return "Hello #{aFirstName} #{aSecondName}"
end


# so which object owns these methods, anyhow? 
# The following test reveals all...
print( "The 'free standing methods' in this code belong to an object named: " )
puts( self )
print( "which is an instance of the class: " )
puts( self.class )

#Free-standing methods (like those above which are not defined within a 
#specific class) are methods (strictly speaking, 'private' methods) of
#the main object which Ruby creates automtically. The following code 
#displays a list of the main object's private methods. Look carefully and
#you will find showname, return_name and return_name2 in that list
puts( "It contains these private methods: " )
puts( self.private_methods )