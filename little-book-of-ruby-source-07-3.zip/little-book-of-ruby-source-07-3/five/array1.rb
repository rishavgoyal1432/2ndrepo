# Ruby Sample program from www.sapphiresteel.com / www.bitwisemag.com

arr = ['a', 'b', 'c']

puts(arr[0])  # shows �a�
puts(arr[1])  # shows �b�
puts(arr[2])  # shows �c�

puts(arr[3]) # nil