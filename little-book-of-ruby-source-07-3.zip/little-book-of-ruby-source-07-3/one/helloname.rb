# Ruby Sample program from www.sapphiresteel.com / www.bitwisemag.com

print('Enter your name: ' )
name = gets()
puts( "Hello #{name}" )