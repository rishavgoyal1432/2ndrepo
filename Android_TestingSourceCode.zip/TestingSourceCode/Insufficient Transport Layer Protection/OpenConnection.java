import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;


public class Test4 {
// No vulnerability here
// open.Connection pattern

	public  static void main(String[] args) throws IOException {
		URL url = new URL("http://any-site");
		URLConnection con = url.openConnection();
		   //SSLException thrown here if server certificate is invalid
		con.getInputStream();

	}

}
