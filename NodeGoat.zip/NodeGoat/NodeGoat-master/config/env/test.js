var testConfig = {
    port: 5051
};

module.exports = testConfig;
